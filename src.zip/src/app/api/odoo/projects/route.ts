import { NextResponse } from "next/server";
import { odooSearchRead } from "@/lib/odoo";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET() {
  try {

    const session = await getServerSession(authOptions);
    const githubId = (session as any)?.githubId;
    if (!githubId) return NextResponse.json({ ok:false, error:"No githubId" }, { status: 401 });

    const users = await odooSearchRead(
      "res.users",
      [["oauth_uid", "=", String(githubId)]],
      ["id"],
      1
    );
    if (!users.length) throw new Error("Usuario Odoo no encontrado por oauth_uid");

    const odooUserId = users[0].id;
    const projects = await odooSearchRead(
      "server.repos",
      [],
      [
        "id",
        "repo_name",
        "project_states",
        "type_deploy_repository",
        "active",
        "base_version",
        "branch_version",
        "image_type_scope",
        "user_id",
        "login_user",
        "owner_id",
        "html_url",
        "ssh_url",
      ],
      100
    );
    return NextResponse.json({ ok: true, projects });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message }, { status: 500 });
  }
}
