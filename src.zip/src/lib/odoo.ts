// src/lib/odoo.ts
type Json = any;

const ODOO_URL = process.env.ODOO_URL!;
const ODOO_DB = process.env.ODOO_DB!;
const ODOO_LOGIN = process.env.ODOO_LOGIN!;
const ODOO_PASSWORD = process.env.ODOO_PASSWORD!;

async function odooAuthenticate(): Promise<{ cookie: string }> {
  const r = await fetch(`${ODOO_URL}/web/session/authenticate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      method: "call",
      params: { db: ODOO_DB, login: ODOO_LOGIN, password: ODOO_PASSWORD },
    }),
    cache: "no-store",
  });

  const setCookie = r.headers.get("set-cookie") || "";
  if (!setCookie) throw new Error("Odoo auth: missing set-cookie");
  return { cookie: setCookie };
}

// ✅ ESTE es el export que te falta
export async function odooCall<T = Json>(
  model: string,
  method: string,
  args: any[] = [],
  kwargs: Record<string, any> = {}
): Promise<T> {
  const { cookie } = await odooAuthenticate();

  const r = await fetch(`${ODOO_URL}/web/dataset/call_kw`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Cookie: cookie, // ✅ reenvío cookie para evitar Session expired
    },
    body: JSON.stringify({
      jsonrpc: "2.0",
      method: "call",
      params: {
        model,
        method,
        args,
        kwargs,
      },
    }),
    cache: "no-store",
  });

    const text = await r.text(); // 👈 lee crudo (sirve aunque sea HTML o vacío)

  console.log("🧾 Odoo status:", r.status, r.statusText);
  console.log("🧾 Odoo content-type:", r.headers.get("content-type"));
  console.log("🧾 Odoo body head:", text.slice(0, 300));

  let data: any;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error("Odoo RPC no devolvió JSON (revisa la consola del servidor de Next).");
  }

  if (data?.error) throw new Error(data.error?.data?.message || data.error?.message || "Odoo RPC error");
  return data.result as T;
}

export async function odooSearchRead(
  model: string,
  domain: any[],
  fields: string[],
  limit = 80,
  offset = 0,
  order = ""
) {
  return odooCall<any[]>(model, "search_read", [domain, fields, offset, limit, order]);
}

export async function odooWrite(model: string, ids: number[], values: Record<string, any>) {
  return odooCall<boolean>(model, "write", [ids, values]);
}
