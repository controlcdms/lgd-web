// src/lib/auth.ts
import GitHubProvider from "next-auth/providers/github";
import type { NextAuthOptions } from "next-auth";

export const authOptions: NextAuthOptions = {
  providers: [
    GitHubProvider({
      clientId: process.env.GITHUB_CLIENT_ID!,
      clientSecret: process.env.GITHUB_CLIENT_SECRET!,
      authorization: { params: { scope: "read:user user:email repo" } }, // ajusta scopes
    }),
  ],
  callbacks: {
    async jwt({ token, account, profile }) {
      // Guardamos access_token en JWT (server-side)
      if (account?.access_token) token.accessToken = account.access_token;

      // Guardamos info útil del user
      // @ts-ignore
      token.githubLogin = (profile as any)?.login || token.githubLogin;
      // @ts-ignore
      token.email = (profile as any)?.email || token.email;
      if (profile) {
        token.githubId = (profile as any).id; // oauth_uid para GitHub
      }

      return token;
    },
    async session({ session, token }) {
      // asegúrate que exista user
      if (session.user) {
        // @ts-ignore
        session.user.githubLogin = token.githubLogin;
        // @ts-ignore
        session.user.email = token.email;

        // ✅ ESTA es la que te falta
        // @ts-ignore
        session.githubId = token.githubId;         // o session.user.githubId, pero sé consistente
        // @ts-ignore
        session.user.githubId = token.githubId;    // yo pondría este y listo
      }
      return session;
    },
    async signIn({ account, profile }) {
      try {
        const access_token = account?.access_token;
        const github_login = (profile as any)?.login;
        const email = (profile as any)?.email;

        if (!access_token || !github_login) return true;

        // llamamos a nuestra API interna (server -> server)
        const base = process.env.NEXTAUTH_URL || "http://localhost:3000";
        await fetch(`${base}/api/odoo/save-token`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ access_token, github_login, email }),
        });

        return true;
      } catch {
        // si falla guardar token, igual deja loguear (o return false si quieres bloquear)
        return true;
      }
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
};
